document.addEventListener("DOMContentLoaded", function () {
  const chatMessages = document.getElementById("chat-messages");
  const userMessageInput = document.getElementById("user-message");
  const sendButton = document.getElementById("send-button");

  sendButton.addEventListener("click", function () {
    sendMessage();
  });

  userMessageInput.addEventListener("keydown", function (event) {
    if (event.key === "Enter") {
      sendMessage();
    }
  });

  function sendMessage() {
    const userMessage = userMessageInput.value.trim();
    if (userMessage === "") return; // Evita enviar mensagens em branco

    const userMessageElement = document.createElement("div");
    userMessageElement.className = "message user";
    userMessageElement.textContent = userMessage;

    chatMessages.appendChild(userMessageElement);

    // Limpa o campo de entrada
    userMessageInput.value = "";

    // Simula a resposta do agente após um curto período de tempo
    setTimeout(function () {
      const agentMessageElement = document.createElement("div");
      agentMessageElement.className = "message agent";
      agentMessageElement.textContent =
        "desculpe amiga, esse chat não existe :( ";
      chatMessages.appendChild(agentMessageElement);
    }, 1000);
  }
});
